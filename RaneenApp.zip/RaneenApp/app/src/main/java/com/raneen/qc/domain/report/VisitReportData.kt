package com.raneen.qc.domain.report

import com.raneen.qc.data.entity.*

data class ReportRuleRow(
    val rule: RuleEntity,
    val isViolated: Boolean,
    val note: String?,
    val photoPaths: List<String>
)

data class ReportCategorySection(
    val category: CategoryEntity,
    val rules: List<ReportRuleRow>
) {
    val deductedPoints: Int get() = rules.filter { it.isViolated }.sumOf { it.rule.points }
    val earnedPoints: Int get() = (category.totalPoints - deductedPoints).coerceAtLeast(0)
}

data class ReportDepartmentSection(
    val department: DepartmentEntity,
    val categories: List<ReportCategorySection>
) {
    val maxPoints: Int get() = categories.sumOf { it.category.totalPoints }
    val earnedPoints: Int get() = categories.sumOf { it.earnedPoints }
    val violatedRules: List<ReportRuleRow> get() = categories.flatMap { it.rules }.filter { it.isViolated }
}

data class ReportPriceViolationRow(
    val departmentName: String,
    val type: PriceViolationType,
    val count: Int,
    val value: Double
)

data class ReportDisplayToolsRow(
    val label: String,
    val entry: DisplayToolsEntryEntity
)

data class VisitReportData(
    val visit: VisitEntity,
    val branchName: String,
    val inspectorName: String,
    val departmentSections: List<ReportDepartmentSection>,
    val priceViolations: List<ReportPriceViolationRow>,
    val displayTools: List<ReportDisplayToolsRow>
) {
    val overallMaxPoints: Int get() = departmentSections.sumOf { it.maxPoints }
    val overallEarnedPoints: Int get() = departmentSections.sumOf { it.earnedPoints }
    val overallPercentage: Double
        get() = if (overallMaxPoints == 0) 0.0 else (overallEarnedPoints.toDouble() / overallMaxPoints) * 100.0
}
