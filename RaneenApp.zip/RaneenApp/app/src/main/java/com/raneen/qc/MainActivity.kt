package com.raneen.qc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.LayoutDirection
import com.raneen.qc.ui.navigation.RaneenNavGraph
import com.raneen.qc.ui.theme.RaneenTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as RaneenApplication

        setContent {
            CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
                RaneenTheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        RaneenNavGraph(context = this, repository = app.repository)
                    }
                }
            }
        }
    }
}
