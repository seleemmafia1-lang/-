package com.raneen.qc.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.raneen.qc.data.entity.UserEntity
import com.raneen.qc.data.repository.RaneenRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val currentUser: UserEntity? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class AuthViewModel(private val repository: RaneenRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun login(username: String, password: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            val user = repository.login(username.trim(), password)
            _uiState.value = if (user != null) {
                AuthUiState(currentUser = user)
            } else {
                AuthUiState(errorMessage = "اسم المستخدم أو كلمة المرور غير صحيحة")
            }
        }
    }

    fun logout() {
        _uiState.value = AuthUiState()
    }
}
