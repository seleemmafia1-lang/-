package com.raneen.qc.data.dao

import androidx.room.*
import com.raneen.qc.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE username = :username AND isActive = 1 LIMIT 1")
    suspend fun findByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getById(id: Long): UserEntity?

    @Query("SELECT * FROM users ORDER BY fullName")
    fun observeAll(): Flow<List<UserEntity>>

    @Insert
    suspend fun insert(user: UserEntity): Long

    @Update
    suspend fun update(user: UserEntity)

    @Query("SELECT COUNT(*) FROM users")
    suspend fun count(): Int
}

@Dao
interface BranchDao {
    @Query("SELECT * FROM branches ORDER BY name")
    fun observeAll(): Flow<List<BranchEntity>>

    @Query("SELECT * FROM branches WHERE id = :id")
    suspend fun getById(id: Long): BranchEntity?

    @Insert
    suspend fun insert(branch: BranchEntity): Long

    @Query("SELECT COUNT(*) FROM branches")
    suspend fun count(): Int
}

@Dao
interface DepartmentDao {
    @Query("SELECT * FROM departments ORDER BY orderIndex")
    fun observeAll(): Flow<List<DepartmentEntity>>

    @Query("SELECT * FROM departments ORDER BY orderIndex")
    suspend fun getAll(): List<DepartmentEntity>

    @Insert
    suspend fun insertAll(items: List<DepartmentEntity>): List<Long>

    @Update
    suspend fun update(department: DepartmentEntity)

    @Delete
    suspend fun delete(department: DepartmentEntity)

    @Query("SELECT COUNT(*) FROM departments")
    suspend fun count(): Int
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories WHERE departmentId = :departmentId ORDER BY orderIndex")
    fun observeByDepartment(departmentId: Long): Flow<List<CategoryEntity>>

    @Transaction
    @Query("SELECT * FROM categories WHERE departmentId = :departmentId ORDER BY orderIndex")
    fun observeWithRules(departmentId: Long): Flow<List<CategoryWithRules>>

    @Insert
    suspend fun insertAll(items: List<CategoryEntity>): List<Long>

    @Update
    suspend fun update(category: CategoryEntity)

    @Delete
    suspend fun delete(category: CategoryEntity)
}

@Dao
interface RuleDao {
    @Query("SELECT * FROM rules WHERE categoryId = :categoryId ORDER BY orderIndex")
    fun observeByCategory(categoryId: Long): Flow<List<RuleEntity>>

    @Query("""
        SELECT rules.* FROM rules
        INNER JOIN categories ON rules.categoryId = categories.id
        WHERE categories.departmentId = :departmentId
        AND rules.text LIKE '%' || :query || '%'
        ORDER BY rules.orderIndex
    """)
    fun searchInDepartment(departmentId: Long, query: String): Flow<List<RuleEntity>>

    @Insert
    suspend fun insertAll(items: List<RuleEntity>): List<Long>

    @Update
    suspend fun update(rule: RuleEntity)

    @Delete
    suspend fun delete(rule: RuleEntity)
}
