package com.raneen.qc.domain

import com.raneen.qc.data.entity.RuleEntity
import com.raneen.qc.data.entity.RuleEvaluationEntity

data class DepartmentScore(
    val departmentId: Long,
    val maxPoints: Int,
    val deductedPoints: Int
) {
    val earnedPoints: Int get() = (maxPoints - deductedPoints).coerceAtLeast(0)
    val percentage: Double get() = if (maxPoints == 0) 0.0 else (earnedPoints.toDouble() / maxPoints) * 100.0
}

object ScoringEngine {
    /**
     * درجة القسم = مجموع درجات الضوابط - درجات الضوابط المؤشَّرة كمخالفة.
     * نفس المعادلة للنوعين REGULAR (مربع X) و SPECIAL (مخالف/غير مخالف)
     * لأن كليهما يخصم درجة الضابط بالكامل عند التأشير كمخالفة.
     */
    fun computeDepartmentScore(
        departmentId: Long,
        rules: List<RuleEntity>,
        evaluations: List<RuleEvaluationEntity>
    ): DepartmentScore {
        val maxPoints = rules.sumOf { it.points }
        val violatedRuleIds = evaluations.filter { it.isViolated }.map { it.ruleId }.toSet()
        val deducted = rules.filter { it.id in violatedRuleIds }.sumOf { it.points }
        return DepartmentScore(departmentId, maxPoints, deducted)
    }

    fun overallPercentage(scores: List<DepartmentScore>): Double {
        val maxTotal = scores.sumOf { it.maxPoints }
        val earnedTotal = scores.sumOf { it.earnedPoints }
        return if (maxTotal == 0) 0.0 else (earnedTotal.toDouble() / maxTotal) * 100.0
    }
}
