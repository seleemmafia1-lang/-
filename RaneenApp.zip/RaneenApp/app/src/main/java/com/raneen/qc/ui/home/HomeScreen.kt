package com.raneen.qc.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raneen.qc.data.entity.UserEntity
import com.raneen.qc.data.entity.UserRole

@Composable
fun HomeScreen(
    user: UserEntity,
    onNewVisit: () -> Unit,
    onMyVisits: () -> Unit,
    onAdmin: () -> Unit,
    onDashboard: () -> Unit,
    onLogout: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("رنين - ${roleLabel(user.role)}") },
                actions = { TextButton(onClick = onLogout) { Text("خروج") } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("مرحبًا، ${user.fullName}", style = MaterialTheme.typography.titleLarge)

            if (user.role == UserRole.QUALITY_INSPECTOR) {
                Button(onClick = onNewVisit, modifier = Modifier.fillMaxWidth()) { Text("زيارة جديدة") }
                OutlinedButton(onClick = onMyVisits, modifier = Modifier.fillMaxWidth()) { Text("زياراتي") }
            }

            if (user.role == UserRole.AREA_QC_MANAGER || user.role == UserRole.QC_MANAGER) {
                Button(onClick = onDashboard, modifier = Modifier.fillMaxWidth()) { Text("لوحة التقارير") }
            }

            if (user.role == UserRole.ADMIN) {
                Button(onClick = onAdmin, modifier = Modifier.fillMaxWidth()) { Text("إدارة المستخدمين والأقسام") }
            }
        }
    }
}

private fun roleLabel(role: UserRole): String = when (role) {
    UserRole.ADMIN -> "مدير النظام"
    UserRole.QUALITY_INSPECTOR -> "مراقب جودة"
    UserRole.AREA_QC_MANAGER -> "مدير منطقة الرقابة والجودة"
    UserRole.QC_MANAGER -> "مدير الرقابة والجودة"
}
