package com.raneen.qc.domain.report

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint

private const val PAGE_WIDTH = 595   // A4 @72dpi
private const val PAGE_HEIGHT = 842
private const val MARGIN = 36f

class PdfContentWriter {
    val document = PdfDocument()
    private var pageNumber = 0
    private var page: PdfDocument.Page = startNewPage()
    private var canvas = page.canvas
    private var y = MARGIN

    private fun startNewPage(): PdfDocument.Page {
        pageNumber += 1
        val info = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
        return document.startPage(info)
    }

    private fun ensureSpace(height: Float) {
        if (y + height > PAGE_HEIGHT - MARGIN) {
            document.finishPage(page)
            page = startNewPage()
            canvas = page.canvas
            y = MARGIN
        }
    }

    private fun textPaint(sizeSp: Float, bold: Boolean, color: Int = Color.BLACK): TextPaint =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = sizeSp
            isFakeBoldText = bold
            this.color = color
        }

    private fun layoutFor(text: String, paint: TextPaint, width: Int): StaticLayout {
        val builder = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setLineSpacing(0f, 1.1f)
        return builder.build()
    }

    fun drawText(text: String, sizeSp: Float = 11f, bold: Boolean = false, color: Int = Color.BLACK) {
        val paint = textPaint(sizeSp, bold, color)
        val width = (PAGE_WIDTH - 2 * MARGIN).toInt()
        val layout = layoutFor(text, paint, width)
        ensureSpace(layout.height.toFloat() + 6f)
        canvas.save()
        canvas.translate(MARGIN, y)
        layout.draw(canvas)
        canvas.restore()
        y += layout.height + 6f
    }

    fun drawDivider() {
        ensureSpace(10f)
        val paint = Paint().apply { color = Color.LTGRAY; strokeWidth = 1f }
        canvas.drawLine(MARGIN, y, PAGE_WIDTH - MARGIN, y, paint)
        y += 10f
    }

    fun spacer(height: Float = 8f) {
        ensureSpace(height)
        y += height
    }

    /** جدول بسيط: عمود لكل نص، عرض العمود بالنسبة من عرض الصفحة */
    fun drawTableRow(cells: List<String>, weights: List<Float>, sizeSp: Float = 10f, bold: Boolean = false, headerBg: Boolean = false) {
        val totalWidth = PAGE_WIDTH - 2 * MARGIN
        val paint = textPaint(sizeSp, bold)
        val layouts = cells.mapIndexed { i, cell ->
            val colWidth = (totalWidth * weights[i]).toInt().coerceAtLeast(20)
            layoutFor(cell, paint, colWidth)
        }
        val rowHeight = (layouts.maxOfOrNull { it.height } ?: 0) + 8
        ensureSpace(rowHeight.toFloat())

        if (headerBg) {
            val bg = Paint().apply { color = Color.parseColor("#EFEFEF") }
            canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + rowHeight, bg)
        }

        var x = PAGE_WIDTH - MARGIN // نرسم من اليمين لليسار (RTL)
        cells.forEachIndexed { i, cell ->
            val colWidth = totalWidth * weights[i]
            x -= colWidth
            val layout = layouts[i]
            canvas.save()
            canvas.translate(x, y + 4f)
            layout.draw(canvas)
            canvas.restore()
        }
        y += rowHeight
        val linePaint = Paint().apply { color = Color.parseColor("#DDDDDD"); strokeWidth = 0.5f }
        canvas.drawLine(MARGIN, y, PAGE_WIDTH - MARGIN, y, linePaint)
    }

    fun drawImage(bitmap: Bitmap, maxWidthPt: Float = 160f, maxHeightPt: Float = 160f) {
        val scale = minOf(maxWidthPt / bitmap.width, maxHeightPt / bitmap.height, 1f)
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        ensureSpace(h + 8f)
        canvas.drawBitmap(bitmap, null, android.graphics.RectF(PAGE_WIDTH - MARGIN - w, y, PAGE_WIDTH - MARGIN, y + h), null)
        y += h + 8f
    }

    /** شعار مركزي أعلى الصفحة */
    fun drawCenteredImage(bitmap: Bitmap, maxWidthPt: Float = 90f, maxHeightPt: Float = 90f) {
        val scale = minOf(maxWidthPt / bitmap.width, maxHeightPt / bitmap.height, 1f)
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        ensureSpace(h + 8f)
        val x = (PAGE_WIDTH - w) / 2f
        canvas.drawBitmap(bitmap, null, android.graphics.RectF(x, y, x + w, y + h), null)
        y += h + 8f
    }

    fun signatureLine(label: String) {
        ensureSpace(30f)
        val paint = textPaint(11f, false)
        val layout = layoutFor("$label: __________________________", paint, (PAGE_WIDTH - 2 * MARGIN).toInt())
        canvas.save()
        canvas.translate(MARGIN, y)
        layout.draw(canvas)
        canvas.restore()
        y += layout.height + 16f
    }

    fun finishAndSave(file: java.io.File) {
        document.finishPage(page)
        java.io.FileOutputStream(file).use { document.writeTo(it) }
        document.close()
    }
}
