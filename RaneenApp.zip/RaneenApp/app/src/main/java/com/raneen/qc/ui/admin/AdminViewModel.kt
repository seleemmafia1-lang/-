package com.raneen.qc.ui.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.raneen.qc.data.entity.UserRole
import com.raneen.qc.data.repository.RaneenRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AdminViewModel(private val repository: RaneenRepository) : ViewModel() {

    val users = repository.observeUsers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val branches = repository.observeBranches().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val departments = repository.observeDepartments().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun createUser(username: String, password: String, fullName: String, role: UserRole) {
        viewModelScope.launch { repository.createUser(username, password, fullName, role) }
    }

    fun addBranch(name: String) {
        viewModelScope.launch { repository.addBranch(name) }
    }
}
