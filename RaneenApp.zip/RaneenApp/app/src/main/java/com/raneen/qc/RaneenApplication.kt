package com.raneen.qc

import android.app.Application
import com.raneen.qc.data.RaneenDatabase
import com.raneen.qc.data.SeedDataLoader
import com.raneen.qc.data.repository.RaneenRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class RaneenApplication : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    lateinit var database: RaneenDatabase
        private set
    lateinit var repository: RaneenRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = RaneenDatabase.getInstance(this)
        repository = RaneenRepository(database)
        applicationScope.launch {
            SeedDataLoader.seedIfEmpty(applicationContext, database)
        }
    }
}
