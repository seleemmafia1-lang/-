package com.raneen.qc.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * IN_PROGRESS -> المفتش لسه بيقيّم الزيارة
 * COMPLETED   -> المفتش أنهى الزيارة وأنشأ التقرير، بانتظار مراجعة مدير منطقة الرقابة والجودة
 * REVIEWED    -> مدير المنطقة اعتمد التقرير، بقى ظاهر لمدير الرقابة والجودة
 */
enum class VisitStatus { IN_PROGRESS, COMPLETED, REVIEWED }

@Entity(tableName = "visits")
data class VisitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val visitNumber: String,          // معرّف فريد لكل زيارة
    val branchId: Long,
    val inspectorUserId: Long,
    val visitDateEpochMillis: Long,
    val status: VisitStatus = VisitStatus.IN_PROGRESS,
    val inspectorSignaturePath: String? = null,
    val qcManagerSignaturePath: String? = null,
    // مراجعة مدير منطقة الرقابة والجودة قبل وصول التقرير لمدير الرقابة والجودة
    val reviewedByUserId: Long? = null,
    val reviewNote: String? = null,
    val reviewedAtEpochMillis: Long? = null
)

/** تقييم كل ضابط داخل الزيارة - يخدم نموذجي X والـ مخالف/غير مخالف بنفس الآلية */
@Entity(tableName = "rule_evaluations")
data class RuleEvaluationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val visitId: Long,
    val ruleId: Long,
    val isViolated: Boolean = false,
    val note: String? = null
)

@Entity(tableName = "violation_photos")
data class ViolationPhotoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ruleEvaluationId: Long,
    val photoPath: String
)

/** حصر مخالفات الأسعار - نموذج مستقل لكل قسم داخل الزيارة */
enum class PriceViolationType { NO_SHELF_TAG, MISMATCH, DISPLAY_SIGN, PRICE_SIGN }

@Entity(tableName = "price_violations")
data class PriceViolationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val visitId: Long,
    val departmentId: Long,
    val type: PriceViolationType,
    val count: Int = 0,
    val value: Double = 0.0
)

/** حصر أدوات العرض - لأقسام: منزلي/ألعاب/مفروشات/كهرباء، بالإضافة لسطر "الأثاث" كبند فرعي
 *  داخل قسم المفروشات (وليس قسمًا مستقلاً - لا يوجد له شيت تقييم خاص بالإكسل).
 *  rowLabel = null يعني السطر الأساسي للقسم، أو "الأثاث" للسطر الفرعي تحت المفروشات. */
@Entity(tableName = "display_tools_entries")
data class DisplayToolsEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val visitId: Long,
    val departmentId: Long,
    val rowLabel: String? = null,
    val rulers: Int = 0,          // المساطر
    val dividers: Int = 0,        // السدبات
    val acrylicSheets: Int = 0,   // الاكليريك
    val acrylicHalfA6: Int = 0,   // أكلريك 1/2 A6
    val polystyrene: Int = 0      // بولسترين
)
