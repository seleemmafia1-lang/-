package com.raneen.qc.domain.report

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private fun xmlEscape(text: String): String = text
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")

class SimpleDocxWriter {
    private val body = StringBuilder()
    private val images = mutableListOf<Pair<ByteArray, String>>() // (bytes, extension) -> word/media/imageN.ext

    fun addHeading(text: String, sizeHalfPoints: Int = 32) {
        body.append(
            """<w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr>
               <w:r><w:rPr><w:rtl/><w:b/><w:sz w:val="$sizeHalfPoints"/></w:rPr><w:t xml:space="preserve">${xmlEscape(text)}</w:t></w:r></w:p>""".trimIndent()
        )
    }

    fun addParagraph(text: String, sizeHalfPoints: Int = 22, bold: Boolean = false) {
        val boldTag = if (bold) "<w:b/>" else ""
        body.append(
            """<w:p><w:pPr><w:bidi/></w:pPr>
               <w:r><w:rPr><w:rtl/>$boldTag<w:sz w:val="$sizeHalfPoints"/></w:rPr><w:t xml:space="preserve">${xmlEscape(text)}</w:t></w:r></w:p>""".trimIndent()
        )
    }

    fun addTable(headerRow: List<String>, rows: List<List<String>>) {
        val sb = StringBuilder("<w:tbl><w:tblPr><w:tblStyle w:val=\"TableGrid\"/><w:bidiVisual/><w:tblW w:w=\"0\" w:type=\"auto\"/><w:tblBorders>" +
            "<w:top w:val=\"single\" w:sz=\"4\"/><w:left w:val=\"single\" w:sz=\"4\"/><w:bottom w:val=\"single\" w:sz=\"4\"/>" +
            "<w:right w:val=\"single\" w:sz=\"4\"/><w:insideH w:val=\"single\" w:sz=\"4\"/><w:insideV w:val=\"single\" w:sz=\"4\"/>" +
            "</w:tblBorders></w:tblPr><w:tblGrid>")
        headerRow.forEach { sb.append("<w:gridCol/>") }
        sb.append("</w:tblGrid>")

        fun rowXml(cells: List<String>, bold: Boolean): String {
            val cellsXml = cells.joinToString("") { cell ->
                val boldTag = if (bold) "<w:b/>" else ""
                """<w:tc><w:p><w:pPr><w:bidi/></w:pPr><w:r><w:rPr><w:rtl/>$boldTag</w:rPr>
                   <w:t xml:space="preserve">${xmlEscape(cell)}</w:t></w:r></w:p></w:tc>""".trimIndent()
            }
            return "<w:tr>$cellsXml</w:tr>"
        }

        sb.append(rowXml(headerRow, bold = true))
        rows.forEach { sb.append(rowXml(it, bold = false)) }
        sb.append("</w:tbl>")
        body.append(sb)
        body.append("<w:p/>") // فراغ بعد الجدول
    }

    /** يضيف صورة (JPEG أو PNG) بعرض/ارتفاع ثابت بالنقاط (تحويل تقريبي لـ EMU) */
    fun addImage(imageBytes: ByteArray, widthPt: Int = 160, heightPt: Int = 160, extension: String = "jpeg", centered: Boolean = false) {
        images.add(imageBytes to extension)
        val imageIndex = images.size
        val relId = "rIdImg$imageIndex"
        val emuW = widthPt * 12700
        val emuH = heightPt * 12700
        val jc = if (centered) "<w:jc w:val=\"center\"/>" else ""
        body.append(
            """<w:p><w:pPr><w:bidi/>$jc</w:pPr><w:r><w:rPr><w:rtl/></w:rPr><w:drawing>
               <wp:inline distT="0" distB="0" distL="0" distR="0">
               <wp:extent cx="$emuW" cy="$emuH"/>
               <wp:docPr id="$imageIndex" name="Image$imageIndex"/>
               <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
               <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
               <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
               <pic:nvPicPr><pic:cNvPr id="$imageIndex" name="Image$imageIndex"/><pic:cNvPicPr/></pic:nvPicPr>
               <pic:blipFill><a:blip r:embed="$relId"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>
               <pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$emuW" cy="$emuH"/></a:xfrm>
               <a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>
               </pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"""
        )
    }

    fun build(outputFile: File) {
        val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
            <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
            <Default Extension="xml" ContentType="application/xml"/>
            <Default Extension="jpeg" ContentType="image/jpeg"/>
            <Default Extension="png" ContentType="image/png"/>
            <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
            </Types>""".trimIndent()

        val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
            <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
            </Relationships>""".trimIndent()

        val docRelsEntries = images.indices.joinToString("") { i ->
            val n = i + 1
            val ext = images[i].second
            """<Relationship Id="rIdImg$n" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image$n.$ext"/>"""
        }
        val docRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
            $docRelsEntries
            </Relationships>""".trimIndent()

        val document = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
                        xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
                        xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">
            <w:body>
            $body
            <w:sectPr><w:bidi/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1080" w:right="1080" w:bottom="1080" w:left="1080"/></w:sectPr>
            </w:body>
            </w:document>""".trimIndent()

        FileOutputStream(outputFile).use { fos ->
            ZipOutputStream(fos).use { zip ->
                fun writeEntry(path: String, content: ByteArray) {
                    zip.putNextEntry(ZipEntry(path))
                    zip.write(content)
                    zip.closeEntry()
                }
                writeEntry("[Content_Types].xml", contentTypes.toByteArray(Charsets.UTF_8))
                writeEntry("_rels/.rels", rootRels.toByteArray(Charsets.UTF_8))
                writeEntry("word/document.xml", document.toByteArray(Charsets.UTF_8))
                writeEntry("word/_rels/document.xml.rels", docRels.toByteArray(Charsets.UTF_8))
                images.forEachIndexed { i, (bytes, ext) -> writeEntry("word/media/image${i + 1}.$ext", bytes) }
            }
        }
    }
}
