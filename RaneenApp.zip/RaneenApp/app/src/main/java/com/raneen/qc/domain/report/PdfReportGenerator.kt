package com.raneen.qc.domain.report

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object PdfReportGenerator {

    fun generate(context: Context, report: VisitReportData, outputFile: File) {
        val writer = PdfContentWriter()

        // --- ترويسة رسمية ---
        val logo = runCatching {
            context.assets.open("logo_raneen.png").use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
        if (logo != null) {
            writer.drawCenteredImage(logo, maxWidthPt = 90f, maxHeightPt = 90f)
        } else {
            writer.drawText("شركة رنين", sizeSp = 20f, bold = true)
        }
        writer.drawText("إدارة الرقابة والجودة", sizeSp = 13f)
        writer.spacer(6f)
        writer.drawText("تقرير تقييم معرض", sizeSp = 16f, bold = true)
        writer.drawDivider()

        val dateStr = SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale("ar")).format(Date(report.visit.visitDateEpochMillis))
        writer.drawText("رقم الزيارة: ${report.visit.visitNumber}")
        writer.drawText("الفرع: ${report.branchName}")
        writer.drawText("تاريخ الزيارة: $dateStr")
        writer.drawText("المفتش: ${report.inspectorName}")
        writer.spacer(4f)
        writer.drawText(
            "الدرجة الإجمالية: ${report.overallEarnedPoints} / ${report.overallMaxPoints} (${"%.1f".format(report.overallPercentage)}%)",
            sizeSp = 13f, bold = true, color = Color.parseColor("#0E5C5C")
        )
        writer.drawDivider()

        // --- درجات الأقسام ---
        writer.drawText("درجات الأقسام", sizeSp = 14f, bold = true)
        writer.drawTableRow(listOf("القسم", "الدرجة"), listOf(0.75f, 0.25f), bold = true, headerBg = true)
        report.departmentSections.forEach { section ->
            writer.drawTableRow(
                listOf(section.department.name, "${section.earnedPoints} / ${section.maxPoints}"),
                listOf(0.75f, 0.25f)
            )
        }
        writer.spacer(10f)

        // --- الضوابط المخالفة وصورها ---
        val allViolations = report.departmentSections.flatMap { section -> section.violatedRules.map { section.department.name to it } }
        if (allViolations.isNotEmpty()) {
            writer.drawText("الضوابط المخالفة", sizeSp = 14f, bold = true)
            allViolations.forEach { (deptName, row) ->
                writer.drawText("[$deptName] ${row.rule.text} (-${row.rule.points})", sizeSp = 10.5f)
                row.photoPaths.forEach { path ->
                    val bmp = runCatching { BitmapFactory.decodeFile(path) }.getOrNull()
                    if (bmp != null) writer.drawImage(bmp)
                }
            }
            writer.spacer(10f)
        }

        // --- حصر مخالفات الأسعار ---
        if (report.priceViolations.any { it.count > 0 || it.value > 0.0 }) {
            writer.drawText("حصر مخالفات الأسعار", sizeSp = 14f, bold = true)
            writer.drawTableRow(listOf("القسم", "النوع", "عدد", "قيمة"), listOf(0.35f, 0.30f, 0.15f, 0.20f), bold = true, headerBg = true)
            report.priceViolations.filter { it.count > 0 || it.value > 0.0 }.forEach { row ->
                writer.drawTableRow(
                    listOf(row.departmentName, priceTypeLabel(row.type), row.count.toString(), row.value.toString()),
                    listOf(0.35f, 0.30f, 0.15f, 0.20f)
                )
            }
            writer.spacer(10f)
        }

        // --- حصر أدوات العرض ---
        if (report.displayTools.isNotEmpty()) {
            writer.drawText("حصر أدوات العرض", sizeSp = 14f, bold = true)
            writer.drawTableRow(
                listOf("القسم", "مساطر", "سدبات", "اكليريك", "أكلريك 1/2", "بولسترين"),
                listOf(0.30f, 0.14f, 0.14f, 0.14f, 0.14f, 0.14f), bold = true, headerBg = true
            )
            report.displayTools.forEach { row ->
                writer.drawTableRow(
                    listOf(
                        row.label, row.entry.rulers.toString(), row.entry.dividers.toString(),
                        row.entry.acrylicSheets.toString(), row.entry.acrylicHalfA6.toString(), row.entry.polystyrene.toString()
                    ),
                    listOf(0.30f, 0.14f, 0.14f, 0.14f, 0.14f, 0.14f)
                )
            }
            writer.spacer(16f)
        }

        // --- التوقيعات ---
        writer.drawDivider()
        writer.signatureLine("توقيع مراقب الجودة")
        writer.signatureLine("توقيع مدير الرقابة والجودة")

        writer.finishAndSave(outputFile)
    }

    private fun priceTypeLabel(type: com.raneen.qc.data.entity.PriceViolationType): String = when (type) {
        com.raneen.qc.data.entity.PriceViolationType.NO_SHELF_TAG -> "بدون شيلف"
        com.raneen.qc.data.entity.PriceViolationType.MISMATCH -> "عدم تطابق"
        com.raneen.qc.data.entity.PriceViolationType.DISPLAY_SIGN -> "صاين عرض"
        com.raneen.qc.data.entity.PriceViolationType.PRICE_SIGN -> "صاين سعر"
    }
}
