package com.raneen.qc.data.dao

import androidx.room.*
import com.raneen.qc.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface VisitDao {
    @Insert
    suspend fun insert(visit: VisitEntity): Long

    @Update
    suspend fun update(visit: VisitEntity)

    @Query("SELECT * FROM visits WHERE id = :id")
    suspend fun getById(id: Long): VisitEntity?

    @Query("SELECT * FROM visits ORDER BY visitDateEpochMillis DESC")
    fun observeAll(): Flow<List<VisitEntity>>

    @Query("SELECT * FROM visits WHERE inspectorUserId = :inspectorId ORDER BY visitDateEpochMillis DESC")
    fun observeByInspector(inspectorId: Long): Flow<List<VisitEntity>>

    @Query("SELECT * FROM visits WHERE status = :status ORDER BY visitDateEpochMillis DESC")
    fun observeByStatus(status: VisitStatus): Flow<List<VisitEntity>>

    @Query("SELECT COUNT(*) FROM visits")
    suspend fun countAll(): Int
}

@Dao
interface RuleEvaluationDao {
    @Query("SELECT * FROM rule_evaluations WHERE visitId = :visitId")
    fun observeByVisit(visitId: Long): Flow<List<RuleEvaluationEntity>>

    @Query("SELECT * FROM rule_evaluations WHERE visitId = :visitId AND ruleId = :ruleId LIMIT 1")
    suspend fun findByVisitAndRule(visitId: Long, ruleId: Long): RuleEvaluationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(evaluation: RuleEvaluationEntity): Long

    @Query("""
        SELECT COALESCE(SUM(rules.points), 0) FROM rule_evaluations
        INNER JOIN rules ON rule_evaluations.ruleId = rules.id
        WHERE rule_evaluations.visitId = :visitId AND rule_evaluations.isViolated = 1
    """)
    suspend fun sumDeductedPointsForVisit(visitId: Long): Int
}

@Dao
interface ViolationPhotoDao {
    @Query("SELECT * FROM violation_photos WHERE ruleEvaluationId = :ruleEvaluationId")
    fun observeByEvaluation(ruleEvaluationId: Long): Flow<List<ViolationPhotoEntity>>

    @Insert
    suspend fun insert(photo: ViolationPhotoEntity): Long

    @Delete
    suspend fun delete(photo: ViolationPhotoEntity)
}

@Dao
interface PriceViolationDao {
    @Query("SELECT * FROM price_violations WHERE visitId = :visitId")
    fun observeByVisit(visitId: Long): Flow<List<PriceViolationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: PriceViolationEntity): Long
}

@Dao
interface DisplayToolsDao {
    @Query("SELECT * FROM display_tools_entries WHERE visitId = :visitId")
    fun observeByVisit(visitId: Long): Flow<List<DisplayToolsEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: DisplayToolsEntryEntity): Long
}
