package com.raneen.qc.data.repository

import com.raneen.qc.data.RaneenDatabase
import com.raneen.qc.data.PasswordHasher
import com.raneen.qc.data.entity.*
import kotlinx.coroutines.flow.Flow

class RaneenRepository(private val db: RaneenDatabase) {

    // --- Auth ---
    suspend fun login(username: String, password: String): UserEntity? {
        val user = db.userDao().findByUsername(username) ?: return null
        return if (PasswordHasher.verify(password, user.salt, user.passwordHash)) user else null
    }

    suspend fun createUser(username: String, password: String, fullName: String, role: UserRole): Long {
        val (hash, salt) = PasswordHasher.hash(password)
        return db.userDao().insert(UserEntity(username = username, passwordHash = hash, salt = salt, fullName = fullName, role = role))
    }

    fun observeUsers(): Flow<List<UserEntity>> = db.userDao().observeAll()

    suspend fun resetPassword(user: UserEntity, newPassword: String) {
        val (hash, salt) = PasswordHasher.hash(newPassword)
        db.userDao().update(user.copy(passwordHash = hash, salt = salt))
    }

    // --- Branches ---
    fun observeBranches(): Flow<List<BranchEntity>> = db.branchDao().observeAll()
    suspend fun addBranch(name: String): Long = db.branchDao().insert(BranchEntity(name = name))
    suspend fun getBranch(id: Long): BranchEntity? = db.branchDao().getById(id)
    suspend fun getUser(id: Long): UserEntity? = db.userDao().getById(id)

    // --- Catalog (departments/categories/rules) ---
    fun observeDepartments(): Flow<List<DepartmentEntity>> = db.departmentDao().observeAll()
    suspend fun getDepartments(): List<DepartmentEntity> = db.departmentDao().getAll()
    fun observeCategories(departmentId: Long): Flow<List<CategoryEntity>> = db.categoryDao().observeByDepartment(departmentId)
    fun observeCategoriesWithRules(departmentId: Long): Flow<List<CategoryWithRules>> = db.categoryDao().observeWithRules(departmentId)
    fun observeRules(categoryId: Long): Flow<List<RuleEntity>> = db.ruleDao().observeByCategory(categoryId)
    fun searchRules(departmentId: Long, query: String): Flow<List<RuleEntity>> = db.ruleDao().searchInDepartment(departmentId, query)

    suspend fun updateDepartment(dept: DepartmentEntity) = db.departmentDao().update(dept)
    suspend fun deleteDepartment(dept: DepartmentEntity) = db.departmentDao().delete(dept)
    suspend fun updateCategory(cat: CategoryEntity) = db.categoryDao().update(cat)
    suspend fun deleteCategory(cat: CategoryEntity) = db.categoryDao().delete(cat)
    suspend fun updateRule(rule: RuleEntity) = db.ruleDao().update(rule)
    suspend fun deleteRule(rule: RuleEntity) = db.ruleDao().delete(rule)

    // --- Visits ---
    suspend fun createVisit(visit: VisitEntity): Long = db.visitDao().insert(visit)
    suspend fun updateVisit(visit: VisitEntity) = db.visitDao().update(visit)
    suspend fun getVisit(id: Long): VisitEntity? = db.visitDao().getById(id)
    fun observeAllVisits(): Flow<List<VisitEntity>> = db.visitDao().observeAll()
    fun observeVisitsByInspector(inspectorId: Long): Flow<List<VisitEntity>> = db.visitDao().observeByInspector(inspectorId)
    fun observeVisitsByStatus(status: VisitStatus): Flow<List<VisitEntity>> = db.visitDao().observeByStatus(status)
    suspend fun approveVisit(visitId: Long, reviewerUserId: Long, note: String?) {
        val visit = db.visitDao().getById(visitId) ?: return
        db.visitDao().update(
            visit.copy(
                status = VisitStatus.REVIEWED,
                reviewedByUserId = reviewerUserId,
                reviewNote = note,
                reviewedAtEpochMillis = System.currentTimeMillis()
            )
        )
    }
    suspend fun nextVisitNumber(): String {
        val count = db.visitDao().countAll()
        return "V-${System.currentTimeMillis().toString().takeLast(6)}-${count + 1}"
    }

    // --- Rule evaluations & photos ---
    fun observeEvaluations(visitId: Long): Flow<List<RuleEvaluationEntity>> = db.ruleEvaluationDao().observeByVisit(visitId)
    suspend fun setRuleViolation(visitId: Long, ruleId: Long, isViolated: Boolean, note: String?): Long {
        val existing = db.ruleEvaluationDao().findByVisitAndRule(visitId, ruleId)
        val entity = existing?.copy(isViolated = isViolated, note = note)
            ?: RuleEvaluationEntity(visitId = visitId, ruleId = ruleId, isViolated = isViolated, note = note)
        return db.ruleEvaluationDao().upsert(entity)
    }
    suspend fun totalDeductedPoints(visitId: Long): Int = db.ruleEvaluationDao().sumDeductedPointsForVisit(visitId)

    fun observePhotos(ruleEvaluationId: Long): Flow<List<ViolationPhotoEntity>> = db.violationPhotoDao().observeByEvaluation(ruleEvaluationId)
    suspend fun addPhoto(ruleEvaluationId: Long, path: String): Long = db.violationPhotoDao().insert(ViolationPhotoEntity(ruleEvaluationId = ruleEvaluationId, photoPath = path))
    suspend fun deletePhoto(photo: ViolationPhotoEntity) = db.violationPhotoDao().delete(photo)

    // --- Price violations ---
    fun observePriceViolations(visitId: Long): Flow<List<PriceViolationEntity>> = db.priceViolationDao().observeByVisit(visitId)
    suspend fun setPriceViolation(item: PriceViolationEntity): Long = db.priceViolationDao().upsert(item)

    // --- Display tools inventory ---
    fun observeDisplayTools(visitId: Long): Flow<List<DisplayToolsEntryEntity>> = db.displayToolsDao().observeByVisit(visitId)
    suspend fun setDisplayTools(item: DisplayToolsEntryEntity): Long = db.displayToolsDao().upsert(item)
}
