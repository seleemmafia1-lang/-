package com.raneen.qc.ui.review

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raneen.qc.data.entity.VisitEntity
import com.raneen.qc.ui.visit.StatusBadge
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ReviewQueueScreen(
    viewModel: ReviewViewModel,
    title: String,
    showPendingTab: Boolean = true,
    onOpenVisit: (Long) -> Unit
) {
    val pending by viewModel.pendingReview.collectAsState()
    val reviewedList by viewModel.reviewed.collectAsState()
    val branches by viewModel.branches.collectAsState()
    val users by viewModel.users.collectAsState()
    val branchNameById = remember(branches) { branches.associateBy({ it.id }, { it.name }) }
    val inspectorNameById = remember(users) { users.associateBy({ it.id }, { it.fullName }) }

    var tab by remember { mutableStateOf(if (showPendingTab) 0 else 1) }

    Scaffold(topBar = { TopAppBar(title = { Text(title) }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (showPendingTab) {
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("بانتظار المراجعة (${pending.size})") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("معتمدة (${reviewedList.size})") })
                }
            }

            val list = if (tab == 0) pending else reviewedList
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    Text(if (tab == 0) "لا توجد تقارير بانتظار المراجعة" else "لا توجد تقارير معتمدة بعد")
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(16.dp)) {
                    items(list) { visit: VisitEntity ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), onClick = { onOpenVisit(visit.id) }) {
                            Column(Modifier.padding(16.dp)) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(branchNameById[visit.branchId] ?: "", style = MaterialTheme.typography.titleMedium)
                                    StatusBadge(visit.status)
                                }
                                Text("المفتش: ${inspectorNameById[visit.inspectorUserId] ?: ""}", style = MaterialTheme.typography.bodySmall)
                                Text(visit.visitNumber, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar")).format(Date(visit.visitDateEpochMillis)),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
