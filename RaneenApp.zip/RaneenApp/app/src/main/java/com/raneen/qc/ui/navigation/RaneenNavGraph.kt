package com.raneen.qc.ui.navigation

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.FileProvider
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.raneen.qc.data.entity.DepartmentEntity
import com.raneen.qc.data.entity.UserRole
import com.raneen.qc.data.entity.VisitStatus
import com.raneen.qc.data.repository.RaneenRepository
import com.raneen.qc.ui.RaneenViewModelFactory
import com.raneen.qc.ui.admin.AdminScreen
import com.raneen.qc.ui.admin.AdminViewModel
import com.raneen.qc.ui.auth.AuthViewModel
import com.raneen.qc.ui.auth.LoginScreen
import com.raneen.qc.ui.displaytools.DisplayToolsScreen
import com.raneen.qc.ui.evaluation.SectionEvaluationScreen
import com.raneen.qc.ui.home.HomeScreen
import com.raneen.qc.ui.priceviolations.PriceViolationsScreen
import com.raneen.qc.ui.review.ReviewQueueScreen
import com.raneen.qc.ui.review.ReviewViewModel
import com.raneen.qc.ui.review.VisitDetailScreen
import com.raneen.qc.ui.summary.ReportReadyScreen
import com.raneen.qc.ui.summary.VisitSummaryScreen
import com.raneen.qc.ui.visit.MyVisitsScreen
import com.raneen.qc.ui.visit.NewVisitScreen
import com.raneen.qc.ui.visit.VisitDepartmentListScreen
import com.raneen.qc.ui.visit.VisitViewModel
import java.io.File

private object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val NEW_VISIT = "new_visit"
    const val VISIT_DEPARTMENTS = "visit_departments/{visitId}"
    const val EVALUATION = "evaluation/{visitId}/{departmentId}"
    const val PRICE_VIOLATIONS = "price_violations/{visitId}"
    const val DISPLAY_TOOLS = "display_tools/{visitId}"
    const val SUMMARY = "summary/{visitId}"
    const val REPORT_READY = "report_ready"
    const val ADMIN = "admin"
    const val MY_VISITS = "my_visits"
    const val REVIEW_QUEUE = "review_queue"
    const val REVIEWED_REPORTS = "reviewed_reports"
    const val VISIT_DETAIL = "visit_detail/{visitId}/{canApprove}"
}

@Composable
fun RaneenNavGraph(context: Context, repository: RaneenRepository) {
    val navController = rememberNavController()
    val factory = RaneenViewModelFactory(repository)
    val authViewModel: AuthViewModel = viewModel(factory)
    val visitViewModel: VisitViewModel = viewModel(factory)
    val adminViewModel: AdminViewModel = viewModel(factory)
    val reviewViewModel: ReviewViewModel = viewModel(factory)

    val authState by authViewModel.uiState.collectAsState()

    NavHost(navController = navController, startDestination = Routes.LOGIN) {
        composable(Routes.LOGIN) {
            LoginScreen(viewModel = authViewModel, onLoginSuccess = {
                navController.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } }
            })
        }

        composable(Routes.HOME) {
            val user = authState.currentUser ?: return@composable
            HomeScreen(
                user = user,
                onNewVisit = { navController.navigate(Routes.NEW_VISIT) },
                onMyVisits = { navController.navigate(Routes.MY_VISITS) },
                onAdmin = { navController.navigate(Routes.ADMIN) },
                onDashboard = {
                    if (user.role == UserRole.AREA_QC_MANAGER) navController.navigate(Routes.REVIEW_QUEUE)
                    else navController.navigate(Routes.REVIEWED_REPORTS)
                },
                onLogout = {
                    authViewModel.logout()
                    navController.navigate(Routes.LOGIN) { popUpTo(0) }
                }
            )
        }

        composable(Routes.NEW_VISIT) {
            val user = authState.currentUser ?: return@composable
            NewVisitScreen(
                viewModel = visitViewModel,
                inspectorUserId = user.id,
                onVisitCreated = { visitId ->
                    navController.navigate("visit_departments/$visitId") { popUpTo(Routes.NEW_VISIT) { inclusive = true } }
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.VISIT_DEPARTMENTS) { backStackEntry ->
            val visitId = backStackEntry.arguments?.get("visitId")?.toString()?.toLongOrNull() ?: return@composable
            VisitDepartmentListScreen(
                viewModel = visitViewModel,
                visitId = visitId,
                onOpenDepartment = { deptId -> navController.navigate("evaluation/$visitId/$deptId") },
                onOpenPriceViolations = { navController.navigate("price_violations/$visitId") },
                onOpenDisplayTools = { navController.navigate("display_tools/$visitId") },
                onFinishVisit = { navController.navigate("summary/$visitId") }
            )
        }

        composable(Routes.EVALUATION) { backStackEntry ->
            val visitId = backStackEntry.arguments?.get("visitId")?.toString()?.toLongOrNull() ?: return@composable
            val departmentId = backStackEntry.arguments?.get("departmentId")?.toString()?.toLongOrNull() ?: return@composable
            val departments by visitViewModel.departments.collectAsState()
            val department = departments.find { it.id == departmentId } ?: return@composable

            var pendingEvaluationId by remember { mutableStateOf<Long?>(null) }
            var pendingPhotoFile by remember { mutableStateOf<File?>(null) }

            val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
                if (success && pendingEvaluationId != null && pendingPhotoFile != null) {
                    visitViewModel.addPhoto(pendingEvaluationId!!, pendingPhotoFile!!.absolutePath)
                }
            }

            SectionEvaluationScreen(
                viewModel = visitViewModel,
                visitId = visitId,
                department = department,
                onAddPhoto = { evaluationId ->
                    pendingEvaluationId = evaluationId
                    val photosDir = File(context.getExternalFilesDir("visit_photos"), "")
                    photosDir.mkdirs()
                    val file = File(photosDir, "violation_${evaluationId}_${System.currentTimeMillis()}.jpg")
                    pendingPhotoFile = file
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                    cameraLauncher.launch(uri)
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.PRICE_VIOLATIONS) { backStackEntry ->
            val visitId = backStackEntry.arguments?.get("visitId")?.toString()?.toLongOrNull() ?: return@composable
            PriceViolationsScreen(viewModel = visitViewModel, visitId = visitId)
        }

        composable(Routes.DISPLAY_TOOLS) { backStackEntry ->
            val visitId = backStackEntry.arguments?.get("visitId")?.toString()?.toLongOrNull() ?: return@composable
            DisplayToolsScreen(viewModel = visitViewModel, visitId = visitId)
        }

        composable(Routes.SUMMARY) { backStackEntry ->
            val visitId = backStackEntry.arguments?.get("visitId")?.toString()?.toLongOrNull() ?: return@composable
            VisitSummaryScreen(
                viewModel = visitViewModel,
                visitId = visitId,
                onFinish = { navController.navigate(Routes.REPORT_READY) }
            )
        }

        composable(Routes.REPORT_READY) {
            val files by visitViewModel.lastGeneratedFiles.collectAsState()
            files?.let { generated ->
                ReportReadyScreen(
                    files = generated,
                    onDone = { navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } } }
                )
            }
        }

        composable(Routes.ADMIN) {
            AdminScreen(viewModel = adminViewModel)
        }

        composable(Routes.MY_VISITS) {
            val user = authState.currentUser ?: return@composable
            MyVisitsScreen(
                viewModel = visitViewModel,
                inspectorUserId = user.id,
                onOpenVisit = { visitId, status ->
                    if (status == VisitStatus.IN_PROGRESS) {
                        navController.navigate("visit_departments/$visitId")
                    } else {
                        navController.navigate("visit_detail/$visitId/false")
                    }
                }
            )
        }

        composable(Routes.REVIEW_QUEUE) {
            ReviewQueueScreen(
                viewModel = reviewViewModel,
                title = "مراجعة التقارير",
                showPendingTab = true,
                onOpenVisit = { visitId -> navController.navigate("visit_detail/$visitId/true") }
            )
        }

        composable(Routes.REVIEWED_REPORTS) {
            ReviewQueueScreen(
                viewModel = reviewViewModel,
                title = "التقارير المعتمدة",
                showPendingTab = false,
                onOpenVisit = { visitId -> navController.navigate("visit_detail/$visitId/false") }
            )
        }

        composable(Routes.VISIT_DETAIL) { backStackEntry ->
            val user = authState.currentUser ?: return@composable
            val visitId = backStackEntry.arguments?.get("visitId")?.toString()?.toLongOrNull() ?: return@composable
            val canApprove = backStackEntry.arguments?.get("canApprove")?.toString()?.toBoolean() ?: false
            VisitDetailScreen(
                viewModel = reviewViewModel,
                visitId = visitId,
                canApprove = canApprove,
                reviewerUserId = user.id,
                onApproved = { navController.popBackStack() }
            )
        }
    }
}

@Composable
private inline fun <reified T : androidx.lifecycle.ViewModel> viewModel(factory: RaneenViewModelFactory): T {
    return androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)
}
