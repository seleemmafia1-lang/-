package com.raneen.qc.ui.displaytools

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.raneen.qc.data.entity.DisplayToolsEntryEntity
import com.raneen.qc.ui.visit.VisitViewModel

private val COLUMNS = listOf("المساطر", "السدبات", "الاكليريك", "أكلريك 1/2 A6", "بولسترين")

@Composable
fun DisplayToolsScreen(viewModel: VisitViewModel, visitId: Long) {
    val departments by viewModel.departments.collectAsState()
    val supported = departments.filter { it.supportsDisplayToolsInventory }
    val furnishingsDept = departments.find { it.name == "المفروشات" }
    val entries by viewModel.displayToolsFor(visitId).collectAsState(initial = emptyList())

    Scaffold(topBar = { TopAppBar(title = { Text("حصر أدوات العرض") }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).horizontalScroll(rememberScrollState())) {
            Row {
                HeaderCell("القسم", width = 140.dp)
                COLUMNS.forEach { HeaderCell(it, width = 100.dp) }
            }
            supported.forEach { dept ->
                val entry = entries.find { it.departmentId == dept.id && it.rowLabel == null }
                    ?: DisplayToolsEntryEntity(visitId = visitId, departmentId = dept.id)
                DisplayToolsRow(dept.name, entry) { updated -> viewModel.setDisplayTools(updated) }

                // بند "الأثاث" الفرعي - يظهر مباشرة تحت سطر المفروشات
                if (dept.id == furnishingsDept?.id) {
                    val furnitureEntry = entries.find { it.departmentId == dept.id && it.rowLabel == "الأثاث" }
                        ?: DisplayToolsEntryEntity(visitId = visitId, departmentId = dept.id, rowLabel = "الأثاث")
                    DisplayToolsRow("الأثاث", furnitureEntry) { updated -> viewModel.setDisplayTools(updated) }
                }
            }

            Row {
                HeaderCell("الإجمالي", width = 140.dp)
                val totals = listOf(
                    entries.sumOf { it.rulers },
                    entries.sumOf { it.dividers },
                    entries.sumOf { it.acrylicSheets },
                    entries.sumOf { it.acrylicHalfA6 },
                    entries.sumOf { it.polystyrene }
                )
                totals.forEach { HeaderCell(it.toString(), width = 100.dp) }
            }
        }
    }
}

@Composable
private fun HeaderCell(text: String, width: androidx.compose.ui.unit.Dp) {
    Box(Modifier.width(width).padding(8.dp)) { Text(text, style = MaterialTheme.typography.labelLarge) }
}

@Composable
private fun DisplayToolsRow(
    departmentName: String,
    entry: DisplayToolsEntryEntity,
    onUpdate: (DisplayToolsEntryEntity) -> Unit
) {
    var rulers by remember(entry.id) { mutableStateOf(entry.rulers.toString()) }
    var dividers by remember(entry.id) { mutableStateOf(entry.dividers.toString()) }
    var acrylicSheets by remember(entry.id) { mutableStateOf(entry.acrylicSheets.toString()) }
    var acrylicHalfA6 by remember(entry.id) { mutableStateOf(entry.acrylicHalfA6.toString()) }
    var polystyrene by remember(entry.id) { mutableStateOf(entry.polystyrene.toString()) }

    fun emit() {
        onUpdate(
            entry.copy(
                rulers = rulers.toIntOrNull() ?: 0,
                dividers = dividers.toIntOrNull() ?: 0,
                acrylicSheets = acrylicSheets.toIntOrNull() ?: 0,
                acrylicHalfA6 = acrylicHalfA6.toIntOrNull() ?: 0,
                polystyrene = polystyrene.toIntOrNull() ?: 0
            )
        )
    }

    Row {
        Box(Modifier.width(140.dp).padding(8.dp)) { Text(departmentName) }
        NumberCell(rulers) { rulers = it; emit() }
        NumberCell(dividers) { dividers = it; emit() }
        NumberCell(acrylicSheets) { acrylicSheets = it; emit() }
        NumberCell(acrylicHalfA6) { acrylicHalfA6 = it; emit() }
        NumberCell(polystyrene) { polystyrene = it; emit() }
    }
}

@Composable
private fun NumberCell(value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.width(100.dp).padding(4.dp)
    )
}
