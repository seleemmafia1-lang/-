package com.raneen.qc.ui.visit

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raneen.qc.data.entity.DepartmentEntity

@Composable
fun VisitDepartmentListScreen(
    viewModel: VisitViewModel,
    visitId: Long,
    onOpenDepartment: (Long) -> Unit,
    onOpenPriceViolations: () -> Unit,
    onOpenDisplayTools: () -> Unit,
    onFinishVisit: () -> Unit
) {
    val departments by viewModel.departments.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("أقسام الزيارة") }) },
        bottomBar = {
            BottomAppBar {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = onOpenPriceViolations) { Text("مخالفات الأسعار") }
                    TextButton(onClick = onOpenDisplayTools) { Text("أدوات العرض") }
                    Button(onClick = onFinishVisit) { Text("إنهاء الزيارة") }
                }
            }
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp)) {
            items(departments) { dept: DepartmentEntity ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    onClick = { onOpenDepartment(dept.id) }
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(dept.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (dept.type == com.raneen.qc.data.entity.DepartmentType.REGULAR)
                                "نموذج: تأشير مخالفة (X)" else "نموذج: مخالف / غير مخالف",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
