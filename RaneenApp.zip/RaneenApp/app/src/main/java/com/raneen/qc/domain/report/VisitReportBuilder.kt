package com.raneen.qc.domain.report

import com.raneen.qc.data.entity.PriceViolationType
import com.raneen.qc.data.repository.RaneenRepository
import kotlinx.coroutines.flow.first

object VisitReportBuilder {

    suspend fun build(repository: RaneenRepository, visitId: Long): VisitReportData? {
        val visit = repository.getVisit(visitId) ?: return null
        val branch = repository.getBranch(visit.branchId)
        val inspector = repository.getUser(visit.inspectorUserId)

        val departments = repository.getDepartments()
        val evaluations = repository.observeEvaluations(visitId).first()
        val evaluationByRuleId = evaluations.associateBy { it.ruleId }

        val departmentSections = departments.map { dept ->
            val categories = repository.observeCategoriesWithRules(dept.id).first()
            val categorySections = categories.map { catWithRules ->
                val ruleRows = catWithRules.rules.map { rule ->
                    val eval = evaluationByRuleId[rule.id]
                    val photos = if (eval != null) repository.observePhotos(eval.id).first().map { it.photoPath } else emptyList()
                    ReportRuleRow(
                        rule = rule,
                        isViolated = eval?.isViolated == true,
                        note = eval?.note,
                        photoPaths = photos
                    )
                }
                ReportCategorySection(catWithRules.category, ruleRows)
            }
            ReportDepartmentSection(dept, categorySections)
        }

        val departmentNameById = departments.associateBy({ it.id }, { it.name })
        val priceViolations = repository.observePriceViolations(visitId).first().map {
            ReportPriceViolationRow(
                departmentName = departmentNameById[it.departmentId] ?: "",
                type = it.type,
                count = it.count,
                value = it.value
            )
        }

        val furnishingsId = departments.find { it.name == "المفروشات" }?.id
        // (يُستخدم furnishingsId لو احتجنا لاحقًا لتمييز سطر الأثاث برمجيًا؛ rowLabel كافٍ حاليًا)
        val displayToolsEntries = repository.observeDisplayTools(visitId).first()
        val displayTools = displayToolsEntries.map { entry ->
            val label = entry.rowLabel ?: (departmentNameById[entry.departmentId] ?: "")
            ReportDisplayToolsRow(label, entry)
        }

        return VisitReportData(
            visit = visit,
            branchName = branch?.name ?: "",
            inspectorName = inspector?.fullName ?: "",
            departmentSections = departmentSections,
            priceViolations = priceViolations,
            displayTools = displayTools
        )
    }
}
