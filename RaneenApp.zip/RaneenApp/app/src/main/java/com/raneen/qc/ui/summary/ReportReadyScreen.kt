package com.raneen.qc.ui.summary

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.raneen.qc.domain.report.GeneratedReportFiles
import com.raneen.qc.ui.sharing.FileShareUtils
import com.raneen.qc.ui.sharing.MIME_DOCX
import com.raneen.qc.ui.sharing.MIME_PDF
import com.raneen.qc.ui.sharing.MIME_XLSX

@Composable
fun ReportReadyScreen(files: GeneratedReportFiles, onDone: () -> Unit) {
    val context = LocalContext.current

    Scaffold(topBar = { TopAppBar(title = { Text("التقرير") }) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("تم إنشاء التقرير بنجاح", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))

            Button(onClick = { FileShareUtils.openFile(context, files.pdf, MIME_PDF) }, modifier = Modifier.fillMaxWidth()) {
                Text("فتح PDF")
            }
            OutlinedButton(onClick = { FileShareUtils.shareFile(context, files.pdf, MIME_PDF) }, modifier = Modifier.fillMaxWidth()) {
                Text("مشاركة PDF")
            }
            OutlinedButton(onClick = { FileShareUtils.shareFile(context, files.excel, MIME_XLSX) }, modifier = Modifier.fillMaxWidth()) {
                Text("مشاركة Excel")
            }
            OutlinedButton(onClick = { FileShareUtils.shareFile(context, files.word, MIME_DOCX) }, modifier = Modifier.fillMaxWidth()) {
                Text("مشاركة Word")
            }

            Spacer(Modifier.weight(1f))
            TextButton(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("العودة للرئيسية") }
        }
    }
}
