package com.raneen.qc.ui.review

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.raneen.qc.data.entity.VisitEntity
import com.raneen.qc.data.entity.VisitStatus
import com.raneen.qc.data.repository.RaneenRepository
import com.raneen.qc.domain.report.VisitReportBuilder
import com.raneen.qc.domain.report.VisitReportData
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReviewViewModel(private val repository: RaneenRepository) : ViewModel() {

    val pendingReview = repository.observeVisitsByStatus(VisitStatus.COMPLETED)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val reviewed = repository.observeVisitsByStatus(VisitStatus.REVIEWED)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val branches = repository.observeBranches().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val users = repository.observeUsers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    suspend fun loadReport(visitId: Long): VisitReportData? = VisitReportBuilder.build(repository, visitId)

    fun approveVisit(visitId: Long, reviewerUserId: Long, note: String?, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.approveVisit(visitId, reviewerUserId, note)
            onDone()
        }
    }
}
