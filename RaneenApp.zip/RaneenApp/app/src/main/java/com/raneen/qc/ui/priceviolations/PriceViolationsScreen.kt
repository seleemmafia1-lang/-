package com.raneen.qc.ui.priceviolations

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.raneen.qc.data.entity.DepartmentEntity
import com.raneen.qc.data.entity.PriceViolationEntity
import com.raneen.qc.data.entity.PriceViolationType
import com.raneen.qc.ui.visit.VisitViewModel

private val TYPE_LABELS = mapOf(
    PriceViolationType.NO_SHELF_TAG to "بدون شيلف",
    PriceViolationType.MISMATCH to "عدم تطابق",
    PriceViolationType.DISPLAY_SIGN to "صاين عرض",
    PriceViolationType.PRICE_SIGN to "صاين سعر"
)

@Composable
fun PriceViolationsScreen(viewModel: VisitViewModel, visitId: Long) {
    val departments by viewModel.departments.collectAsState()
    val existing by viewModel.priceViolationsFor(visitId).collectAsState(initial = emptyList())

    Scaffold(topBar = { TopAppBar(title = { Text("حصر مخالفات الأسعار") }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp)) {
            items(departments) { dept: DepartmentEntity ->
                DepartmentPriceViolationCard(
                    department = dept,
                    existing = existing.filter { it.departmentId == dept.id },
                    onChange = { type, count, value ->
                        viewModel.setPriceViolation(visitId, dept.id, type, count, value)
                    }
                )
            }
        }
    }
}

@Composable
private fun DepartmentPriceViolationCard(
    department: DepartmentEntity,
    existing: List<PriceViolationEntity>,
    onChange: (PriceViolationType, Int, Double) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(department.name, style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "إخفاء" else "تعديل") }
            }

            val totalCount = existing.sumOf { it.count }
            val totalValue = existing.sumOf { it.value }
            Text("إجمالي العدد: $totalCount — إجمالي القيمة: $totalValue")

            if (expanded) {
                PriceViolationType.entries.forEach { type ->
                    val current = existing.find { it.type == type }
                    PriceViolationRow(
                        label = TYPE_LABELS[type] ?: type.name,
                        initialCount = current?.count ?: 0,
                        initialValue = current?.value ?: 0.0,
                        onChange = { count, value -> onChange(type, count, value) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PriceViolationRow(
    label: String,
    initialCount: Int,
    initialValue: Double,
    onChange: (Int, Double) -> Unit
) {
    var count by remember { mutableStateOf(initialCount.toString()) }
    var value by remember { mutableStateOf(initialValue.toString()) }

    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, modifier = Modifier.weight(1f))
        OutlinedTextField(
            value = count,
            onValueChange = {
                count = it
                onChange(it.toIntOrNull() ?: 0, value.toDoubleOrNull() ?: 0.0)
            },
            label = { Text("عدد") },
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.width(90.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = {
                value = it
                onChange(count.toIntOrNull() ?: 0, it.toDoubleOrNull() ?: 0.0)
            },
            label = { Text("قيمة") },
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.width(90.dp)
        )
    }
}
