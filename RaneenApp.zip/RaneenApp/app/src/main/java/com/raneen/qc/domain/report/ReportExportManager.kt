package com.raneen.qc.domain.report

import android.content.Context
import java.io.File

data class GeneratedReportFiles(val pdf: File, val excel: File, val word: File)

object ReportExportManager {

    fun exportAll(context: Context, report: VisitReportData): GeneratedReportFiles {
        val dir = File(context.getExternalFilesDir("reports"), "")
        dir.mkdirs()
        val baseName = report.visit.visitNumber

        val pdfFile = File(dir, "$baseName.pdf")
        val excelFile = File(dir, "$baseName.xlsx")
        val wordFile = File(dir, "$baseName.docx")

        PdfReportGenerator.generate(context, report, pdfFile)
        ExcelReportGenerator.generate(report, excelFile)
        WordReportGenerator.generate(context, report, wordFile)

        return GeneratedReportFiles(pdfFile, excelFile, wordFile)
    }
}
