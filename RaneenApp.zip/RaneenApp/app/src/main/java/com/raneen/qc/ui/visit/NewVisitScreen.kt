package com.raneen.qc.ui.visit

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raneen.qc.data.entity.BranchEntity

@Composable
fun NewVisitScreen(
    viewModel: VisitViewModel,
    inspectorUserId: Long,
    onVisitCreated: (Long) -> Unit,
    onBack: () -> Unit
) {
    val branches by viewModel.branches.collectAsState()
    var selectedBranch by remember { mutableStateOf<BranchEntity?>(null) }
    var expanded by remember { mutableStateOf(false) }

    Scaffold(topBar = { TopAppBar(title = { Text("زيارة جديدة") }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp)) {
            Text("اختر الفرع", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = selectedBranch?.name ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("الفرع") },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    branches.forEach { branch ->
                        DropdownMenuItem(text = { Text(branch.name) }, onClick = {
                            selectedBranch = branch
                            expanded = false
                        })
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    selectedBranch?.let { branch ->
                        viewModel.startVisit(branch.id, inspectorUserId, onVisitCreated)
                    }
                },
                enabled = selectedBranch != null,
                modifier = Modifier.fillMaxWidth()
            ) { Text("بدء الزيارة") }

            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onBack) { Text("رجوع") }
        }
    }
}
