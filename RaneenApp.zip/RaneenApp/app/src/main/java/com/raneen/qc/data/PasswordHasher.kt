package com.raneen.qc.data

import java.security.MessageDigest
import java.security.SecureRandom

object PasswordHasher {

    fun hash(password: String): Pair<String, String> {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }.toHex()
        return hashWithSalt(password, salt) to salt
    }

    fun verify(password: String, salt: String, expectedHash: String): Boolean =
        hashWithSalt(password, salt) == expectedHash

    private fun hashWithSalt(password: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt.toByteArray(Charsets.UTF_8))
        val bytes = digest.digest(password.toByteArray(Charsets.UTF_8))
        return bytes.toHex()
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }
}
