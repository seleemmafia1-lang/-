package com.raneen.qc.ui.evaluation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raneen.qc.data.entity.*
import com.raneen.qc.ui.visit.VisitViewModel

@Composable
fun SectionEvaluationScreen(
    viewModel: VisitViewModel,
    visitId: Long,
    department: DepartmentEntity,
    onAddPhoto: (ruleEvaluationId: Long) -> Unit,
    onBack: () -> Unit
) {
    val categoriesWithRules by viewModel.categoriesWithRulesFor(department.id).collectAsState(initial = emptyList())
    val evaluations by viewModel.evaluationsFor(visitId).collectAsState(initial = emptyList())
    var searchQuery by remember { mutableStateOf("") }

    val evaluationByRule = remember(evaluations) { evaluations.associateBy { it.ruleId } }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(title = { Text(department.name) })
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث داخل الضوابط...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp)) {
            categoriesWithRules.forEach { catWithRules ->
                val filteredRules = catWithRules.rules.filter {
                    searchQuery.isBlank() || it.text.contains(searchQuery, ignoreCase = true)
                }
                if (filteredRules.isNotEmpty()) {
                    item {
                        Text(
                            "${catWithRules.category.name} (${catWithRules.category.totalPoints})",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                        )
                    }
                    items(filteredRules) { rule ->
                        RuleRow(
                            rule = rule,
                            departmentType = department.type,
                            evaluation = evaluationByRule[rule.id],
                            onViolationChanged = { isViolated ->
                                viewModel.toggleViolation(visitId, rule.id, isViolated)
                            },
                            onAddPhoto = { evalId -> onAddPhoto(evalId) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RuleRow(
    rule: RuleEntity,
    departmentType: DepartmentType,
    evaluation: RuleEvaluationEntity?,
    onViolationChanged: (Boolean) -> Unit,
    onAddPhoto: (Long) -> Unit
) {
    val isViolated = evaluation?.isViolated == true

    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(rule.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Text("${rule.points}", style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.height(8.dp))

            when (departmentType) {
                DepartmentType.REGULAR -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isViolated, onCheckedChange = onViolationChanged)
                        Text("تسجيل مخالفة (X)")
                    }
                }
                DepartmentType.SPECIAL -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = !isViolated, onClick = { onViolationChanged(false) }, label = { Text("غير مخالف") })
                        FilterChip(selected = isViolated, onClick = { onViolationChanged(true) }, label = { Text("مخالف") })
                    }
                }
            }

            if (isViolated && evaluation != null) {
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { onAddPhoto(evaluation.id) }) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("إضافة صور المخالفة")
                }
            }
        }
    }
}
