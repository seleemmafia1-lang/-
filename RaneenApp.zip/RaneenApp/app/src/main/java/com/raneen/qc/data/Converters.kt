package com.raneen.qc.data

import androidx.room.TypeConverter
import com.raneen.qc.data.entity.*

class Converters {
    @TypeConverter
    fun fromUserRole(value: UserRole): String = value.name
    @TypeConverter
    fun toUserRole(value: String): UserRole = UserRole.valueOf(value)

    @TypeConverter
    fun fromDepartmentType(value: DepartmentType): String = value.name
    @TypeConverter
    fun toDepartmentType(value: String): DepartmentType = DepartmentType.valueOf(value)

    @TypeConverter
    fun fromVisitStatus(value: VisitStatus): String = value.name
    @TypeConverter
    fun toVisitStatus(value: String): VisitStatus = VisitStatus.valueOf(value)

    @TypeConverter
    fun fromPriceViolationType(value: PriceViolationType): String = value.name
    @TypeConverter
    fun toPriceViolationType(value: String): PriceViolationType = PriceViolationType.valueOf(value)
}
