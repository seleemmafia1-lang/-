package com.raneen.qc.ui.visit

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.raneen.qc.data.entity.*
import com.raneen.qc.data.repository.RaneenRepository
import com.raneen.qc.domain.DepartmentScore
import com.raneen.qc.domain.ScoringEngine
import com.raneen.qc.domain.report.GeneratedReportFiles
import com.raneen.qc.domain.report.ReportExportManager
import com.raneen.qc.domain.report.VisitReportBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VisitViewModel(private val repository: RaneenRepository) : ViewModel() {

    val branches = repository.observeBranches().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val departments = repository.observeDepartments().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun visitsForInspector(inspectorId: Long) = repository.observeVisitsByInspector(inspectorId)

    private val _currentVisitId = MutableStateFlow<Long?>(null)
    val currentVisitId: StateFlow<Long?> = _currentVisitId.asStateFlow()

    fun startVisit(branchId: Long, inspectorUserId: Long, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val visitNumber = repository.nextVisitNumber()
            val id = repository.createVisit(
                VisitEntity(
                    visitNumber = visitNumber,
                    branchId = branchId,
                    inspectorUserId = inspectorUserId,
                    visitDateEpochMillis = System.currentTimeMillis()
                )
            )
            _currentVisitId.value = id
            onCreated(id)
        }
    }

    fun categoriesFor(departmentId: Long) = repository.observeCategories(departmentId)
    fun categoriesWithRulesFor(departmentId: Long) = repository.observeCategoriesWithRules(departmentId)
    fun rulesFor(categoryId: Long) = repository.observeRules(categoryId)
    fun searchRules(departmentId: Long, query: String) = repository.searchRules(departmentId, query)
    fun evaluationsFor(visitId: Long) = repository.observeEvaluations(visitId)
    fun photosFor(ruleEvaluationId: Long) = repository.observePhotos(ruleEvaluationId)

    fun toggleViolation(visitId: Long, ruleId: Long, isViolated: Boolean, note: String? = null) {
        viewModelScope.launch { repository.setRuleViolation(visitId, ruleId, isViolated, note) }
    }

    fun addPhoto(ruleEvaluationId: Long, path: String) {
        viewModelScope.launch { repository.addPhoto(ruleEvaluationId, path) }
    }

    fun priceViolationsFor(visitId: Long) = repository.observePriceViolations(visitId)
    fun setPriceViolation(visitId: Long, departmentId: Long, type: PriceViolationType, count: Int, value: Double) {
        viewModelScope.launch {
            repository.setPriceViolation(PriceViolationEntity(visitId = visitId, departmentId = departmentId, type = type, count = count, value = value))
        }
    }

    fun displayToolsFor(visitId: Long) = repository.observeDisplayTools(visitId)
    fun setDisplayTools(entry: DisplayToolsEntryEntity) {
        viewModelScope.launch { repository.setDisplayTools(entry) }
    }

    suspend fun computeDepartmentScore(departmentId: Long, visitId: Long): DepartmentScore {
        val rules = mutableListOf<RuleEntity>()
        categoriesFor(departmentId).first().forEach { cat ->
            rules += rulesFor(cat.id).first()
        }
        val evaluations = evaluationsFor(visitId).first()
        return ScoringEngine.computeDepartmentScore(departmentId, rules, evaluations)
    }

    fun finishVisit(visitId: Long) {
        viewModelScope.launch {
            val visit = repository.getVisit(visitId) ?: return@launch
            repository.updateVisit(visit.copy(status = VisitStatus.COMPLETED))
        }
    }

    private val _lastGeneratedFiles = MutableStateFlow<GeneratedReportFiles?>(null)
    val lastGeneratedFiles: StateFlow<GeneratedReportFiles?> = _lastGeneratedFiles.asStateFlow()
    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    /** إنهاء الزيارة + بناء التقرير + إنشاء PDF/Excel/Word محليًا على الهاتف */
    fun finishVisitAndExport(context: Context, visitId: Long) {
        viewModelScope.launch {
            _isExporting.value = true
            val visit = repository.getVisit(visitId)
            if (visit != null) {
                repository.updateVisit(visit.copy(status = VisitStatus.COMPLETED))
            }
            val report = VisitReportBuilder.build(repository, visitId)
            if (report != null) {
                val files = withContext(Dispatchers.IO) {
                    ReportExportManager.exportAll(context.applicationContext, report)
                }
                _lastGeneratedFiles.value = files
            }
            _isExporting.value = false
        }
    }
}
