package com.raneen.qc.domain.report

import org.dhatim.fastexcel.Workbook
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object ExcelReportGenerator {

    fun generate(report: VisitReportData, outputFile: File) {
        FileOutputStream(outputFile).use { fos ->
            val workbook = Workbook(fos, "Raneen QC", "1.0")

            // --- شيت الملخص ---
            val summary = workbook.newWorksheet("ملخص الزيارة")
            var r = 0
            summary.value(r, 0, "رقم الزيارة"); summary.value(r, 1, report.visit.visitNumber); r++
            summary.value(r, 0, "الفرع"); summary.value(r, 1, report.branchName); r++
            summary.value(r, 0, "المفتش"); summary.value(r, 1, report.inspectorName); r++
            val dateStr = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar")).format(Date(report.visit.visitDateEpochMillis))
            summary.value(r, 0, "تاريخ الزيارة"); summary.value(r, 1, dateStr); r++
            summary.value(r, 0, "الدرجة الإجمالية"); summary.value(r, 1, "${report.overallEarnedPoints} / ${report.overallMaxPoints}"); r++
            summary.value(r, 0, "النسبة"); summary.value(r, 1, "${"%.1f".format(report.overallPercentage)}%"); r += 2

            summary.value(r, 0, "القسم"); summary.value(r, 1, "الدرجة"); summary.style(r, 0).bold().set(); summary.style(r, 1).bold().set(); r++
            report.departmentSections.forEach { section ->
                summary.value(r, 0, section.department.name)
                summary.value(r, 1, "${section.earnedPoints} / ${section.maxPoints}")
                r++
            }
            summary.width(0, 28.0); summary.width(1, 18.0)

            // --- شيت لكل قسم: الفئة، الضابط، الدرجة، مخالف؟ ---
            report.departmentSections.forEach { section ->
                val sheetName = section.department.name.take(28).ifBlank { "قسم" }
                val ws = workbook.newWorksheet(sheetName)
                var row = 0
                ws.value(row, 0, "الفئة"); ws.value(row, 1, "الضابط"); ws.value(row, 2, "الدرجة"); ws.value(row, 3, "مخالف؟")
                (0..3).forEach { c -> ws.style(row, c).bold().set() }
                row++
                section.categories.forEach { cat ->
                    cat.rules.forEach { ruleRow ->
                        ws.value(row, 0, cat.category.name)
                        ws.value(row, 1, ruleRow.rule.text)
                        ws.value(row, 2, ruleRow.rule.points.toDouble())
                        ws.value(row, 3, if (ruleRow.isViolated) "مخالف" else "سليم")
                        row++
                    }
                }
                ws.width(0, 22.0); ws.width(1, 55.0); ws.width(2, 10.0); ws.width(3, 12.0)
            }

            // --- شيت مخالفات الأسعار ---
            if (report.priceViolations.isNotEmpty()) {
                val pv = workbook.newWorksheet("مخالفات الأسعار")
                pv.value(0, 0, "القسم"); pv.value(0, 1, "النوع"); pv.value(0, 2, "عدد"); pv.value(0, 3, "قيمة")
                (0..3).forEach { c -> pv.style(0, c).bold().set() }
                report.priceViolations.forEachIndexed { i, row ->
                    val rIdx = i + 1
                    pv.value(rIdx, 0, row.departmentName)
                    pv.value(rIdx, 1, priceTypeLabel(row.type))
                    pv.value(rIdx, 2, row.count.toDouble())
                    pv.value(rIdx, 3, row.value)
                }
                pv.width(0, 22.0); pv.width(1, 18.0); pv.width(2, 10.0); pv.width(3, 12.0)
            }

            // --- شيت حصر أدوات العرض ---
            if (report.displayTools.isNotEmpty()) {
                val dt = workbook.newWorksheet("حصر أدوات العرض")
                val headers = listOf("القسم", "المساطر", "السدبات", "الاكليريك", "أكلريك 1/2 A6", "بولسترين")
                headers.forEachIndexed { i, h -> dt.value(0, i, h); dt.style(0, i).bold().set() }
                report.displayTools.forEachIndexed { i, row ->
                    val rIdx = i + 1
                    dt.value(rIdx, 0, row.label)
                    dt.value(rIdx, 1, row.entry.rulers.toDouble())
                    dt.value(rIdx, 2, row.entry.dividers.toDouble())
                    dt.value(rIdx, 3, row.entry.acrylicSheets.toDouble())
                    dt.value(rIdx, 4, row.entry.acrylicHalfA6.toDouble())
                    dt.value(rIdx, 5, row.entry.polystyrene.toDouble())
                }
                dt.width(0, 22.0)
            }

            workbook.finish()
        }
    }

    private fun priceTypeLabel(type: com.raneen.qc.data.entity.PriceViolationType): String = when (type) {
        com.raneen.qc.data.entity.PriceViolationType.NO_SHELF_TAG -> "بدون شيلف"
        com.raneen.qc.data.entity.PriceViolationType.MISMATCH -> "عدم تطابق"
        com.raneen.qc.data.entity.PriceViolationType.DISPLAY_SIGN -> "صاين عرض"
        com.raneen.qc.data.entity.PriceViolationType.PRICE_SIGN -> "صاين سعر"
    }
}
