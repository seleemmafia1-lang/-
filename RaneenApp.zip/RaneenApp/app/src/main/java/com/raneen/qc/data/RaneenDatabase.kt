package com.raneen.qc.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.raneen.qc.data.dao.*
import com.raneen.qc.data.entity.*

@Database(
    entities = [
        UserEntity::class,
        BranchEntity::class,
        DepartmentEntity::class,
        CategoryEntity::class,
        RuleEntity::class,
        VisitEntity::class,
        RuleEvaluationEntity::class,
        ViolationPhotoEntity::class,
        PriceViolationEntity::class,
        DisplayToolsEntryEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class RaneenDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun branchDao(): BranchDao
    abstract fun departmentDao(): DepartmentDao
    abstract fun categoryDao(): CategoryDao
    abstract fun ruleDao(): RuleDao
    abstract fun visitDao(): VisitDao
    abstract fun ruleEvaluationDao(): RuleEvaluationDao
    abstract fun violationPhotoDao(): ViolationPhotoDao
    abstract fun priceViolationDao(): PriceViolationDao
    abstract fun displayToolsDao(): DisplayToolsDao

    companion object {
        @Volatile private var INSTANCE: RaneenDatabase? = null

        fun getInstance(context: Context): RaneenDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    RaneenDatabase::class.java,
                    "raneen_qc.db"
                ).fallbackToDestructiveMigration() // مرحلة تطوير - يُستبدل باستراتيجية Migration حقيقية قبل الإصدار
                .build().also { INSTANCE = it }
            }
    }
}
