package com.raneen.qc.domain.report

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object WordReportGenerator {

    fun generate(context: Context, report: VisitReportData, outputFile: File) {
        val writer = SimpleDocxWriter()

        val logoBytes = runCatching { context.assets.open("logo_raneen.png").use { it.readBytes() } }.getOrNull()
        if (logoBytes != null) {
            writer.addImage(logoBytes, widthPt = 90, heightPt = 90, extension = "png", centered = true)
        } else {
            writer.addHeading("شركة رنين", sizeHalfPoints = 40)
        }
        writer.addHeading("إدارة الرقابة والجودة", sizeHalfPoints = 24)
        writer.addParagraph("")
        writer.addHeading("تقرير تقييم معرض", sizeHalfPoints = 32)

        val dateStr = SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale("ar")).format(Date(report.visit.visitDateEpochMillis))
        writer.addParagraph("رقم الزيارة: ${report.visit.visitNumber}")
        writer.addParagraph("الفرع: ${report.branchName}")
        writer.addParagraph("تاريخ الزيارة: $dateStr")
        writer.addParagraph("المفتش: ${report.inspectorName}")
        writer.addParagraph(
            "الدرجة الإجمالية: ${report.overallEarnedPoints} / ${report.overallMaxPoints} (${"%.1f".format(report.overallPercentage)}%)",
            bold = true
        )

        writer.addParagraph("درجات الأقسام", bold = true, sizeHalfPoints = 26)
        writer.addTable(
            headerRow = listOf("القسم", "الدرجة"),
            rows = report.departmentSections.map { listOf(it.department.name, "${it.earnedPoints} / ${it.maxPoints}") }
        )

        val allViolations = report.departmentSections.flatMap { section -> section.violatedRules.map { section.department.name to it } }
        if (allViolations.isNotEmpty()) {
            writer.addParagraph("الضوابط المخالفة والصور", bold = true, sizeHalfPoints = 26)
            allViolations.forEach { (deptName, row) ->
                writer.addParagraph("[$deptName] ${row.rule.text} (-${row.rule.points})")
                row.photoPaths.forEach { path ->
                    val file = File(path)
                    if (file.exists()) {
                        val bytes = runCatching { file.readBytes() }.getOrNull()
                        if (bytes != null) writer.addImage(bytes)
                    }
                }
            }
        }

        if (report.priceViolations.any { it.count > 0 || it.value > 0.0 }) {
            writer.addParagraph("حصر مخالفات الأسعار", bold = true, sizeHalfPoints = 26)
            writer.addTable(
                headerRow = listOf("القسم", "النوع", "عدد", "قيمة"),
                rows = report.priceViolations.filter { it.count > 0 || it.value > 0.0 }.map {
                    listOf(it.departmentName, priceTypeLabel(it.type), it.count.toString(), it.value.toString())
                }
            )
        }

        if (report.displayTools.isNotEmpty()) {
            writer.addParagraph("حصر أدوات العرض", bold = true, sizeHalfPoints = 26)
            writer.addTable(
                headerRow = listOf("القسم", "مساطر", "سدبات", "اكليريك", "أكلريك 1/2 A6", "بولسترين"),
                rows = report.displayTools.map {
                    listOf(
                        it.label, it.entry.rulers.toString(), it.entry.dividers.toString(),
                        it.entry.acrylicSheets.toString(), it.entry.acrylicHalfA6.toString(), it.entry.polystyrene.toString()
                    )
                }
            )
        }

        writer.addParagraph("")
        writer.addParagraph("توقيع مراقب الجودة: __________________________")
        writer.addParagraph("توقيع مدير الرقابة والجودة: __________________________")

        writer.build(outputFile)
    }

    private fun priceTypeLabel(type: com.raneen.qc.data.entity.PriceViolationType): String = when (type) {
        com.raneen.qc.data.entity.PriceViolationType.NO_SHELF_TAG -> "بدون شيلف"
        com.raneen.qc.data.entity.PriceViolationType.MISMATCH -> "عدم تطابق"
        com.raneen.qc.data.entity.PriceViolationType.DISPLAY_SIGN -> "صاين عرض"
        com.raneen.qc.data.entity.PriceViolationType.PRICE_SIGN -> "صاين سعر"
    }
}
