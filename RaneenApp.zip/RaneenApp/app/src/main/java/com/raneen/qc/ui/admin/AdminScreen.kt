package com.raneen.qc.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raneen.qc.data.entity.UserRole

private val ROLE_LABELS = mapOf(
    UserRole.ADMIN to "مدير النظام",
    UserRole.QUALITY_INSPECTOR to "مراقب جودة",
    UserRole.AREA_QC_MANAGER to "مدير منطقة الرقابة والجودة",
    UserRole.QC_MANAGER to "مدير الرقابة والجودة"
)

@Composable
fun AdminScreen(viewModel: AdminViewModel) {
    val users by viewModel.users.collectAsState()
    val branches by viewModel.branches.collectAsState()
    val departments by viewModel.departments.collectAsState()

    var tab by remember { mutableStateOf(0) }

    Scaffold(topBar = { TopAppBar(title = { Text("الإدارة") }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("المستخدمون") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("الفروع") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("الأقسام والضوابط") })
            }

            when (tab) {
                0 -> UsersTab(users = users, onCreate = viewModel::createUser)
                1 -> BranchesTab(branches = branches, onAdd = viewModel::addBranch)
                2 -> DepartmentsTab(departments = departments)
            }
        }
    }
}

@Composable
private fun UsersTab(users: List<com.raneen.qc.data.entity.UserEntity>, onCreate: (String, String, String, UserRole) -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(UserRole.QUALITY_INSPECTOR) }
    var roleExpanded by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("الاسم") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("اسم المستخدم") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("كلمة المرور") }, modifier = Modifier.fillMaxWidth())

        ExposedDropdownMenuBox(expanded = roleExpanded, onExpandedChange = { roleExpanded = it }) {
            OutlinedTextField(
                value = ROLE_LABELS[role] ?: "",
                onValueChange = {},
                readOnly = true,
                label = { Text("الدور") },
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(expanded = roleExpanded, onDismissRequest = { roleExpanded = false }) {
                UserRole.entries.forEach { r ->
                    DropdownMenuItem(text = { Text(ROLE_LABELS[r] ?: r.name) }, onClick = { role = r; roleExpanded = false })
                }
            }
        }

        Button(
            onClick = {
                onCreate(username, password, fullName, role)
                username = ""; password = ""; fullName = ""
            },
            enabled = username.isNotBlank() && password.isNotBlank() && fullName.isNotBlank(),
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        ) { Text("إنشاء مستخدم") }

        Divider(Modifier.padding(vertical = 8.dp))
        LazyColumn {
            items(users) { user ->
                ListItem(headlineContent = { Text(user.fullName) }, supportingContent = { Text("${user.username} — ${ROLE_LABELS[user.role]}") })
            }
        }
    }
}

@Composable
private fun BranchesTab(branches: List<com.raneen.qc.data.entity.BranchEntity>, onAdd: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم الفرع") }, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Button(onClick = { onAdd(name); name = "" }, enabled = name.isNotBlank()) { Text("إضافة") }
        }
        LazyColumn(Modifier.padding(top = 8.dp)) {
            items(branches) { branch -> ListItem(headlineContent = { Text(branch.name) }) }
        }
    }
}

@Composable
private fun DepartmentsTab(departments: List<com.raneen.qc.data.entity.DepartmentEntity>) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        items(departments) { dept ->
            ListItem(
                headlineContent = { Text(dept.name) },
                supportingContent = { Text(if (dept.type == com.raneen.qc.data.entity.DepartmentType.REGULAR) "نموذج X" else "مخالف/غير مخالف") }
            )
        }
    }
}
