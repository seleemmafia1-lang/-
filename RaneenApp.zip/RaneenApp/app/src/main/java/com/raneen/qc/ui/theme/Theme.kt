package com.raneen.qc.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val RaneenTeal = Color(0xFF0E5C5C)
val RaneenTealLight = Color(0xFF15807F)
val RaneenBrass = Color(0xFFC69A3D)
val RaneenBackground = Color(0xFFF7F6F2)
val RaneenSurface = Color(0xFFFFFFFF)
val RaneenDanger = Color(0xFFB3261E)

private val LightColors = lightColorScheme(
    primary = RaneenTeal,
    secondary = RaneenBrass,
    background = RaneenBackground,
    surface = RaneenSurface,
    error = RaneenDanger
)

private val DarkColors = darkColorScheme(
    primary = RaneenTealLight,
    secondary = RaneenBrass,
    error = RaneenDanger
)

@Composable
fun RaneenTheme(darkTheme: Boolean = false, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
