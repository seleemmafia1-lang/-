package com.raneen.qc.data

import android.content.Context
import org.json.JSONObject
import com.raneen.qc.data.entity.*

/**
 * البيانات في seed_departments.json مستخرجة مباشرة من ملف الإكسل الأصلي
 * (التقييم_1_الاوف لاين) - نفس أسماء الشيتات والضوابط والدرجات، وليست معاد كتابتها من الذاكرة.
 *
 * تصنيف نوع القسم (REGULAR / SPECIAL) طبقًا لنص المستند + تأكيد لاحق من المستخدم:
 *  - REGULAR: مربع X لكل ضابط -> الأدوات المنزلية / الألعاب ومستلزمات الأطفال / المفروشات / الكهرباء
 *  - SPECIAL: مخالف/غير مخالف -> مدير المعرض / خدمة العملاء / الكاشير / الكاميرات / الأمن /
 *             الاستلامات / الصيانة / التكييفات / الموارد البشرية / الخدمات (مؤكَّد)
 */
object SeedDataLoader {

    private val REGULAR_DEPARTMENTS = setOf(
        "الادوات المنزلية", "الالعاب ومستلزمات الاطفال", "المفروشات", "الكهرباء"
    )

    // الأقسام التي لها حصر أدوات عرض طبقًا للمستند (الأثاث بند فرعي داخل المفروشات - راجع أسفل)
    private val DISPLAY_TOOLS_DEPARTMENTS = setOf(
        "الادوات المنزلية", "الالعاب ومستلزمات الاطفال", "المفروشات", "الكهرباء"
    )

    suspend fun seedIfEmpty(context: Context, db: RaneenDatabase) {
        if (db.departmentDao().count() > 0) return

        val jsonText = context.assets.open("seed_departments.json")
            .bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = JSONObject(jsonText)

        var deptOrder = 0
        val deptNames = root.keys().asSequence().toList()

        for (deptKey in deptNames) {
            val trimmedKey = deptKey.trim()
            val type = if (REGULAR_DEPARTMENTS.contains(trimmedKey)) DepartmentType.REGULAR else DepartmentType.SPECIAL
            val deptId = db.departmentDao().insertAll(
                listOf(
                    DepartmentEntity(
                        key = deptKey,
                        name = trimmedKey,
                        type = type,
                        orderIndex = deptOrder++,
                        supportsDisplayToolsInventory = DISPLAY_TOOLS_DEPARTMENTS.contains(trimmedKey)
                    )
                )
            ).first()

            val categoriesArray = root.getJSONArray(deptKey)
            var catOrder = 0
            for (i in 0 until categoriesArray.length()) {
                val catObj = categoriesArray.getJSONObject(i)
                val catId = db.categoryDao().insertAll(
                    listOf(
                        CategoryEntity(
                            departmentId = deptId,
                            name = catObj.getString("category"),
                            totalPoints = catObj.getDouble("total_points").toInt(),
                            orderIndex = catOrder++
                        )
                    )
                ).first()

                val rulesArray = catObj.getJSONArray("rules")
                val ruleEntities = mutableListOf<RuleEntity>()
                for (j in 0 until rulesArray.length()) {
                    val ruleObj = rulesArray.getJSONObject(j)
                    ruleEntities.add(
                        RuleEntity(
                            categoryId = catId,
                            ruleNo = ruleObj.getInt("no"),
                            text = ruleObj.getString("text"),
                            points = ruleObj.getDouble("points").toInt(),
                            orderIndex = j
                        )
                    )
                }
                if (ruleEntities.isNotEmpty()) db.ruleDao().insertAll(ruleEntities)
            }
        }

        // قسم الأثاث بند فرعي داخل المفروشات (وليس قسمًا مستقلاً) - يُعرض كسطر إضافي في
        // شاشة حصر أدوات العرض تحت نفس معرّف قسم المفروشات (rowLabel = "الأثاث")

        if (db.userDao().count() == 0) {
            val (hash, salt) = PasswordHasher.hash("admin123")
            db.userDao().insert(
                UserEntity(
                    username = "admin",
                    passwordHash = hash,
                    salt = salt,
                    fullName = "مدير النظام",
                    role = UserRole.ADMIN
                )
            )
        }
    }
}
