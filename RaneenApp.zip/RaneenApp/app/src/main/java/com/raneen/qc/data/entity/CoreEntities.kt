package com.raneen.qc.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** أربعة أدوار طبقًا للمستند: */
enum class UserRole {
    ADMIN,                  // إنشاء مستخدمين، صلاحيات، إدارة الأقسام والضوابط
    QUALITY_INSPECTOR,      // مراقب جودة - ينشئ الزيارات ويقيّم
    AREA_QC_MANAGER,        // مدير منطقة الرقابة والجودة - يراجع تقارير المراقبين
    QC_MANAGER              // مدير الرقابة والجودة - Dashboard كامل
}

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val passwordHash: String,
    val salt: String,
    val fullName: String,
    val role: UserRole,
    val isActive: Boolean = true
)

@Entity(tableName = "branches")
data class BranchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

/**
 * نوع القسم يحدد شكل واجهة التقييم فقط:
 * REGULAR  -> مربع X لكل ضابط (الأدوات المنزلية / الألعاب / المفروشات / الكهرباء)
 * SPECIAL  -> مخالف / غير مخالف (الأقسام التسعة الخاصة + الخدمات)
 * آلية خصم الدرجة نفسها واحدة في الحالتين: عند التأشير كمخالفة تُخصم درجة الضابط بالكامل.
 */
enum class DepartmentType { REGULAR, SPECIAL }

@Entity(tableName = "departments")
data class DepartmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,           // مطابق لاسم الشيت في الإكسل الأصلي
    val name: String,
    val type: DepartmentType,
    val orderIndex: Int,
    val supportsDisplayToolsInventory: Boolean = false // منزلي/ألعاب/مفروشات/كهرباء/أثاث
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val departmentId: Long,
    val name: String,
    val totalPoints: Int,
    val orderIndex: Int
)

@Entity(tableName = "rules")
data class RuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val categoryId: Long,
    val ruleNo: Int,
    val text: String,
    val points: Int,
    val orderIndex: Int
)
