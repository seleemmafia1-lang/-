package com.raneen.qc.ui.review

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raneen.qc.domain.report.VisitReportData
import kotlinx.coroutines.launch

@Composable
fun VisitDetailScreen(
    viewModel: ReviewViewModel,
    visitId: Long,
    canApprove: Boolean,
    reviewerUserId: Long,
    onApproved: () -> Unit
) {
    var report by remember { mutableStateOf<VisitReportData?>(null) }
    var note by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(visitId) { report = viewModel.loadReport(visitId) }

    Scaffold(topBar = { TopAppBar(title = { Text("تفاصيل الزيارة") }) }) { padding ->
        val current = report
        if (current == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(Modifier.fillMaxSize().padding(padding)) {
            LazyColumn(Modifier.weight(1f).padding(16.dp)) {
                item {
                    Text("رقم الزيارة: ${current.visit.visitNumber}", style = MaterialTheme.typography.bodyMedium)
                    Text("الفرع: ${current.branchName}", style = MaterialTheme.typography.bodyMedium)
                    Text("المفتش: ${current.inspectorName}", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "الدرجة الإجمالية: ${current.overallEarnedPoints} / ${current.overallMaxPoints} (${"%.1f".format(current.overallPercentage)}%)",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(16.dp))
                    Text("درجات الأقسام", style = MaterialTheme.typography.titleSmall)
                }
                items(current.departmentSections) { section ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(section.department.name)
                        Text("${section.earnedPoints} / ${section.maxPoints}")
                    }
                }

                val violations = current.departmentSections.flatMap { s -> s.violatedRules.map { s.department.name to it } }
                if (violations.isNotEmpty()) {
                    item { Spacer(Modifier.height(16.dp)); Text("الضوابط المخالفة", style = MaterialTheme.typography.titleSmall) }
                    items(violations) { (deptName, row) ->
                        Text("[$deptName] ${row.rule.text} (-${row.rule.points})", style = MaterialTheme.typography.bodySmall)
                    }
                }

                if (canApprove) {
                    item {
                        Spacer(Modifier.height(16.dp))
                        OutlinedTextField(
                            value = note,
                            onValueChange = { note = it },
                            label = { Text("ملاحظات المراجعة (اختياري)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            if (canApprove) {
                Button(
                    onClick = {
                        scope.launch {
                            viewModel.approveVisit(visitId, reviewerUserId, note.ifBlank { null }, onApproved)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) { Text("اعتماد التقرير") }
            }
        }
    }
}
