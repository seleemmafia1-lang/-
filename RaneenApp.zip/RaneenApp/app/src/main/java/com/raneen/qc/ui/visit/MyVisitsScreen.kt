package com.raneen.qc.ui.visit

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raneen.qc.data.entity.VisitEntity
import com.raneen.qc.data.entity.VisitStatus
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MyVisitsScreen(
    viewModel: VisitViewModel,
    inspectorUserId: Long,
    onOpenVisit: (Long, VisitStatus) -> Unit
) {
    val visits by viewModel.visitsForInspector(inspectorUserId).collectAsState(initial = emptyList())
    val branches by viewModel.branches.collectAsState()
    val branchNameById = remember(branches) { branches.associateBy({ it.id }, { it.name }) }

    Scaffold(topBar = { TopAppBar(title = { Text("زياراتي") }) }) { padding ->
        if (visits.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("لا توجد زيارات بعد")
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp)) {
                items(visits) { visit: VisitEntity ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        onClick = { onOpenVisit(visit.id, visit.status) }
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(branchNameById[visit.branchId] ?: "فرع غير معروف", style = MaterialTheme.typography.titleMedium)
                                StatusBadge(visit.status)
                            }
                            Text(visit.visitNumber, style = MaterialTheme.typography.bodySmall)
                            Text(
                                SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar")).format(Date(visit.visitDateEpochMillis)),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: VisitStatus) {
    val (label, color) = when (status) {
        VisitStatus.IN_PROGRESS -> "جارية" to MaterialTheme.colorScheme.secondary
        VisitStatus.COMPLETED -> "بانتظار المراجعة" to MaterialTheme.colorScheme.tertiary
        VisitStatus.REVIEWED -> "معتمدة" to MaterialTheme.colorScheme.primary
    }
    AssistChip(onClick = {}, label = { Text(label) }, colors = AssistChipDefaults.assistChipColors())
}
