package com.raneen.qc.ui.summary

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.raneen.qc.domain.DepartmentScore
import com.raneen.qc.domain.ScoringEngine
import com.raneen.qc.ui.visit.VisitViewModel

@Composable
fun VisitSummaryScreen(
    viewModel: VisitViewModel,
    visitId: Long,
    onFinish: () -> Unit
) {
    val departments by viewModel.departments.collectAsState()
    val context = LocalContext.current
    var scores by remember { mutableStateOf<List<DepartmentScore>>(emptyList()) }
    val isExporting by viewModel.isExporting.collectAsState()
    val generatedFiles by viewModel.lastGeneratedFiles.collectAsState()

    LaunchedEffect(departments) {
        scores = departments.map { viewModel.computeDepartmentScore(it.id, visitId) }
    }

    LaunchedEffect(generatedFiles) {
        if (generatedFiles != null) onFinish()
    }

    val overall = remember(scores) { ScoringEngine.overallPercentage(scores) }

    Scaffold(topBar = { TopAppBar(title = { Text("ملخص الزيارة") }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("النتيجة الإجمالية: ${"%.1f".format(overall)}%", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(16.dp))

            LazyColumn(Modifier.weight(1f)) {
                items(departments.zip(scores)) { (dept, score) ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(dept.name)
                        Text("${score.earnedPoints} / ${score.maxPoints}")
                    }
                }
            }

            Button(
                onClick = { viewModel.finishVisitAndExport(context, visitId) },
                enabled = !isExporting,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (isExporting) "جاري إنشاء التقرير..." else "إنهاء الزيارة وإنشاء التقرير") }
        }
    }
}
