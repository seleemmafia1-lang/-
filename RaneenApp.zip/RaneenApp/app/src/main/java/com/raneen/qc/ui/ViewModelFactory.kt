package com.raneen.qc.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.raneen.qc.data.repository.RaneenRepository
import com.raneen.qc.ui.auth.AuthViewModel
import com.raneen.qc.ui.visit.VisitViewModel
import com.raneen.qc.ui.admin.AdminViewModel
import com.raneen.qc.ui.review.ReviewViewModel

class RaneenViewModelFactory(private val repository: RaneenRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
        AuthViewModel::class.java -> AuthViewModel(repository) as T
        VisitViewModel::class.java -> VisitViewModel(repository) as T
        AdminViewModel::class.java -> AdminViewModel(repository) as T
        ReviewViewModel::class.java -> ReviewViewModel(repository) as T
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    }
}
